Il y a deux exécutables et leurs .rar de code associés. Il y en a un
avec l’exploration non informée (ai_vacuum_executable_BFS) et l’autre avec
l’exploration informée (ai_vacuum_executable_AStar). 
Pour les exécuter il faut télécharger le dossier portant le même nom, dézipper et cliquer sur l’exécutable
ai_vacuum en laissant bien les autres fichiers contenus dans le dossier.
Les codes se trouvent dans les .rar avec le mot “code”. Il faut les dézipper,
puis aller dans le dossier Assets puis Scripts.