/*#pragma once
#ifndef DEF_RIGIDBODYCONTACT
#define DEF_RIGIDBODYCONTACT
#include"../Particule.h"

class RigidBodyContact {

public : 

    //Constructor
    RigidBodyContact();

	//Calculate and return the separtionVelocity  of the rigidbody
	double calculateSeperatingVelocity(RigidBody* r1, RigidBody* r2);

	
};

#endif*/